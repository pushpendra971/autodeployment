### Pipelines scripts ###

### Push Lambda Code ###
(git commit needed check for the folder exist)
This will push code to the Lambda and based on the branch push to dev/prod OR stage. Environment need to save in the particular manner.

### Push API ###
(no git commit needed).
This will push api and overwrite to the old one + deploy these api.

### Lambda create ###
(git commit check for the folder)
This will create lambda which is created via the developer. 

List of enviroment varibale:

Project_Name  - This will be used as prefix for creating lambda   
API_Gateway_ARN   - This is a role which must have access to invoke lambda & sts assume permission   
Cognito_ARN  - This is ARN for pool id   
stage  - This will show the version of the code 
Role_Associated_With_Lambda  - This is a role which gets associated with each lambda   
BUCKET  - This will be used to store lambda over S3 and from there it will be uploaded to lambda   
REGION  - Region where lambda will run   
API_ID    - The API id for API Gateway   
API_NAME - Prefix for API name   
ENVIRONMENT - The environment will be used for storing variables which will be set in lambda   
TAGS - This will be used for maintaining tags   