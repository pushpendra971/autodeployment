function Run(connector,param,data){
    return new Promise((resolve,reject)=>{
        console.log(param,data);
        connector.cypher({query:param,params: data},function(err,data){
            if(err){
                reject(err);
            }
            resolve(data);
        })
    });
}

module.exports = function(connector){
    return function(param,data){
        return Run(connector,param,data);
    }
}
