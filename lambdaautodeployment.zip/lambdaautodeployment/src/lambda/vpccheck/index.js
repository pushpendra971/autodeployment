    
    var mysql = require('mysql');

    exports.handler = function(event,context,callback) {
        return new Promise((resolve,reject)=>{
            mysql_connection = mysql.createConnection ({
                host: process.env.host,
                user: process.env.user,
                password: process.env.password,
                database: process.env.database,
                port: process.env.port,
            });
            mysql_connection.query(query, async (err, results, fields) => {
                if (err) {
                    console.log(err);
                    return reject(err);
                }
                console.log(results);
                // var data = results.map((item)=> {return item});
                resolve(results);
            });
        });
    }