
    const http = require('http');
    
    exports.handler = function (event,context,callback) {
        // TODO implement
        console.log(event);
        // callback(null,"res");
        call(function(res){
            console.log(res);
            callback(null,res);
        })
    };
    
    function call(callback){
        console.log("called");
    var rds = 'http://facilitybook-logs.cy41fbxeclnp.eu-central-1.rds.amazonaws.com:3306';
    var ec2 = 'http://172.16.1.18:7474';
    http.get(rds, (resp) => {
      let data = '';
    
      // A chunk of data has been recieved.
      resp.on('data', (chunk) => {
        data += chunk;
      });
    
      // The whole response has been received. Print out the result.
      resp.on('end', () => {
          callback(data);
        // console.log(JSON.parse(data).explanation);
      });
    
    }).on("error", (err) => {
      console.log("Error: " + err.message);
    });
    }