var neo4j       = require('./helper/neo4j');
var RUN         = require('./helper/RUN')(neo4j);

exports.handler = function (event,context,callback) {
    // TODO implement
    migration_execute()
    .then(function(r){
        callback(null,r);
    })
    .catch(function(e){
        callback(e);
    })
};

function migration_execute(){
    return new Promise((resolve,reject)=>{ 
        var migration_query = `
            MATCH (n:User)
            where n.carSize is null and n.id is NOT NULL
            set n.carSize = 'large'
            set n.carListSize = ['large']
            
            MATCH (n:User)
            where n.carNumber is null and n.id is NOT NULL
            set n.carNumber = 'xxx'
            set n.carListNumber = ['xxx']

            MATCH (n:User)
            where n.carCategory is null and n.id is NOT NULL
            set n.carCategory = 'normal'
            set n.carListCategory = ['normal']

            MATCH (n:User)
            where n.id is NOT NULL
            set n.carListSize = [n.carSize]
            set n.carListCategory = [n.carCategory]
            set n.carListNumber = [n.carNumber]
            return n.id,n.carSize,n.carCategory,n.carNumber,n.carListSize,n.carListCategory,n.carListNumber
        `;
        RUN(migration_query)
        .then(function(r){
            resolve(r);
        }).then(function(e){
            reject(e);
        })
    })
}